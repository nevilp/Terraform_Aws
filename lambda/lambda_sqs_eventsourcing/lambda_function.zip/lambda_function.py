def lambda_handler(event, context):
    print("Received event:", event)
    return {"statusCode": 200}